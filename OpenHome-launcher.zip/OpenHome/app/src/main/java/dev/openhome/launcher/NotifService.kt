package dev.openhome.launcher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NItem(val app: String, val title: String, val text: String)

/** Нужен только для показа уведомлений на экране блокировки (доступ выдаётся пользователем вручную). */
class NotifService : NotificationListenerService() {
    override fun onListenerConnected() { refresh() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refresh() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refresh() }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun refresh() {
        try {
            items = activeNotifications
                .filter { it.isClearable && it.packageName != packageName && (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
                .sortedByDescending { it.postTime }
                .map {
                    val x = it.notification.extras
                    NItem(
                        appName(it.packageName),
                        x.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "",
                        x.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
                    )
                }
        } catch (e: Exception) {
        }
    }

    companion object {
        @Volatile var items: List<NItem> = emptyList()
    }
}
