package dev.openhome.launcher

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

class AppItem(val pkg: String, val cls: String, val label: String, val raw: Drawable) {
    private val cache = HashMap<String, Bitmap>()

    @Synchronized
    fun icon(shape: Int, px: Int): Bitmap {
        val k = "$shape/$px"
        return cache[k] ?: IconShaper.render(raw, shape, px).also {
            if (cache.size > 4) cache.clear()
            cache[k] = it
        }
    }
}

object AppRepo {
    @Volatile var apps: List<AppItem> = emptyList()

    fun load(ctx: Context) {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(q, 0)
            .map { AppItem(it.activityInfo.packageName, it.activityInfo.name, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }

    fun find(pkg: String): AppItem? = apps.firstOrNull { it.pkg == pkg }
}

/** Единая форма значков (как в ColorOS): адаптивные слои рисуются без системной маски и обрезаются нашей. */
object IconShaper {
    val NAMES = listOf("Системная", "Круг", "Сквиркл", "Скруглённый квадрат", "Квадрат", "Капля")

    fun render(src: Drawable, shape: Int, s: Int): Bitmap {
        val d = src.constantState?.newDrawable()?.mutate() ?: src
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        if (shape == 0) {
            d.setBounds(0, 0, s, s)
            d.draw(c)
            return out
        }
        val content = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val cc = Canvas(content)
        if (d is AdaptiveIconDrawable) {
            val o = s / 4
            d.background?.let { it.setBounds(-o, -o, s + o, s + o); it.draw(cc) }
            d.foreground?.let { it.setBounds(-o, -o, s + o, s + o); it.draw(cc) }
        } else {
            cc.drawColor(0xFFF2F2F7.toInt())
            val p = (s * 0.16f).toInt()
            d.setBounds(p, p, s - p, s - p)
            d.draw(cc)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawPath(mask(shape, s.toFloat()), paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(content, 0f, 0f, paint)
        return out
    }

    private fun mask(shape: Int, s: Float): Path {
        val p = Path()
        when (shape) {
            1 -> p.addCircle(s / 2, s / 2, s / 2, Path.Direction.CW)
            2 -> {
                val r = s / 2.0
                for (k in 0..90) {
                    val a = 2.0 * PI * k / 90
                    val cs = cos(a)
                    val sn = sin(a)
                    val x = (r + r * sign(cs) * abs(cs).pow(0.5)).toFloat()
                    val y = (r + r * sign(sn) * abs(sn).pow(0.5)).toFloat()
                    if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
            3 -> p.addRoundRect(0f, 0f, s, s, s * 0.28f, s * 0.28f, Path.Direction.CW)
            4 -> p.addRoundRect(0f, 0f, s, s, s * 0.1f, s * 0.1f, Path.Direction.CW)
            else -> {
                val h = s / 2
                val t = s * 0.08f
                p.addRoundRect(RectF(0f, 0f, s, s), floatArrayOf(h, h, h, h, h, h, t, t), Path.Direction.CW)
            }
        }
        return p
    }
}
