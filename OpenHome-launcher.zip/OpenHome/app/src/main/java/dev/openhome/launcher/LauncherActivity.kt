package dev.openhome.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.TextClock
import kotlin.math.abs

class LauncherActivity : Activity() {
    private lateinit var root: DragLayout
    private lateinit var content: LinearLayout
    private lateinit var homeGrid: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var drawer: DragLayout
    private lateinit var drawerCol: LinearLayout
    private lateinit var grid: GridView
    private lateinit var search: EditText

    private val h = Handler(Looper.getMainLooper())
    private var shown: List<AppItem> = emptyList()
    private var progress = 0f
    private var dragBase = 0f
    private var anim: ValueAnimator? = null
    private var rev = 0

    private val reloadRun = Runnable { reload() }
    private val pkgRcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            h.removeCallbacks(reloadRun)
            h.postDelayed(reloadRun, 800)
        }
    }

    private val gridAdapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int): Any = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
            val c = (v as? Cell) ?: Cell(this@LauncherActivity)
            c.animate().cancel()
            c.alpha = 1f
            c.scaleX = 1f
            c.scaleY = 1f
            c.translationY = 0f
            bind(c, shown[p], true)
            return c
        }
    }

    // ───────────────────────── жизненный цикл ─────────────────────────

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        rev = Prefs.rev
        build()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        reg(pkgRcv, f)
        reload()
        LockService.ensure(this)
    }

    override fun onDestroy() {
        unregisterReceiver(pkgRcv)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (rev != Prefs.rev) {
            recreate()
            return
        }
        if (progress == 0f && Prefs.animStyle != 3) {
            content.scaleX = 1.06f
            content.scaleY = 1.06f
            content.alpha = 0.4f
            content.animate().scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(dur(300)).setInterpolator(DecelerateInterpolator(1.6f)).start()
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (progress > 0f) animateTo(0f)
    }

    override fun onBackPressed() {
        if (progress > 0f) animateTo(0f)
    }

    // ───────────────────────── интерфейс ─────────────────────────

    private fun textColor(): Int = if (Prefs.darkText) 0xFF101014.toInt() else Color.WHITE

    private fun build() {
        var ui = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (Prefs.darkText) ui = ui or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = ui

        root = DragLayout(this)
        root.addView(View(this).apply { setBackgroundColor(Color.argb(Prefs.dim * 255 / 100, 0, 0, 0)) }, MATCH, MATCH)

        // главный экран: часы, сетка закреплённых приложений, ручка, док
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tc = textColor()
        val fmt = if (Prefs.h24) "HH:mm" else "h:mm"
        val time = TextClock(this).apply {
            format12Hour = fmt
            format24Hour = fmt
            setTextColor(tc)
            when (Prefs.clockStyle) {
                0 -> { textSize = 68f; typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL) }
                1 -> { textSize = 60f; typeface = Typeface.DEFAULT_BOLD }
                else -> { textSize = 52f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) }
            }
            includeFontPadding = false
        }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"
            format24Hour = "EEEE, d MMMM"
            textSize = 15f
            setTextColor(tc)
            alpha = 0.85f
        }
        val clockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(14), dp(10))
        }
        clockBox.addView(time)
        clockBox.addView(date)
        content.addView(clockBox, LinearLayout.LayoutParams(MATCH, WRAP))

        homeGrid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), 0, dp(6), 0)
        }
        content.addView(homeGrid, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val handle = FrameLayout(this)
        handle.addView(
            View(this).apply { background = roundRect(Prefs.accent, dpf(2f)); alpha = 0.8f },
            FrameLayout.LayoutParams(dp(36), dp(4), Gravity.CENTER)
        )
        handle.setOnClickListener { animateTo(1f) }
        content.addView(handle, LinearLayout.LayoutParams(MATCH, dp(28)))

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = roundRect(Color.argb(Prefs.dockAlpha * 255 / 100 / 2, 255, 255, 255), dpf(30f))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        content.addView(dock, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(14), 0, dp(14), dp(8)) })
        root.addView(content, MATCH, MATCH)

        // меню приложений: поиск + сетка
        drawer = DragLayout(this).apply {
            setBackgroundColor(Color.argb(Prefs.drawerAlpha * 255 / 100, 8, 8, 14))
            translationY = 4000f
        }
        search = EditText(this).apply {
            hint = "Поиск приложений"
            setHintTextColor(Color.argb(120, 255, 255, 255))
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = roundRect(Color.argb(36, 255, 255, 255), dpf(24f))
            setPadding(dp(18), dp(12), dp(18), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
            setOnEditorActionListener { v, _, _ ->
                shown.firstOrNull()?.let { launch(it, v) }
                true
            }
        }
        grid = GridView(this).apply {
            numColumns = Prefs.cols
            verticalSpacing = dp(8)
            selector = ColorDrawable(Color.TRANSPARENT)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
            setPadding(dp(6), dp(10), dp(6), dp(24))
            adapter = gridAdapter
        }
        drawerCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        drawerCol.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(12), dp(16), dp(6)) })
        drawerCol.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        drawer.addView(drawerCol, MATCH, MATCH)
        root.addView(drawer, MATCH, MATCH)
        setContentView(root)

        // жесты
        root.canStart = { dy -> dy < 0 && progress == 0f }
        root.onStart = { stopAnim(); dragBase = progress; prep() }
        root.onDrag = { dy -> setProgress(dragBase - dy / span()) }
        root.onEnd = { vy -> release(vy) }
        root.onLong = { quickMenu() }
        drawer.canStart = { dy -> dy > 0 && progress >= 1f && !grid.canScrollList(-1) }
        drawer.onStart = { stopAnim(); dragBase = progress }
        drawer.onDrag = root.onDrag
        drawer.onEnd = root.onEnd

        root.setOnApplyWindowInsetsListener { _, w ->
            content.setPadding(0, w.systemWindowInsetTop, 0, w.systemWindowInsetBottom)
            drawerCol.setPadding(0, w.systemWindowInsetTop, 0, w.systemWindowInsetBottom)
            w
        }
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (anim == null) setProgress(progress) }
    }

    private fun buildHome() {
        homeGrid.removeAllViews()
        val items = Prefs.list(Prefs.home).mapNotNull { AppRepo.find(it) }
        var idx = 0
        for (r in 0 until Prefs.rows) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until Prefs.cols) {
                val cell: View = if (idx < items.size) Cell(this).also { bind(it, items[idx], Prefs.labels) } else View(this)
                idx++
                row.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
            homeGrid.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        }
    }

    private fun buildDock() {
        dock.removeAllViews()
        val items = Prefs.list(Prefs.dock).mapNotNull { AppRepo.find(it) }
        for (a in items) dock.addView(Cell(this).also { bind(it, a, false) }, LinearLayout.LayoutParams(0, WRAP, 1f))
        dock.visibility = if (items.isEmpty()) View.INVISIBLE else View.VISIBLE
    }

    private fun bind(c: Cell, a: AppItem, labels: Boolean) {
        val px = dp(Prefs.iconSize)
        c.set(a.label, a.icon(Prefs.iconShape, px), px, labels, textColor())
        c.setOnClickListener { launch(a, c) }
        c.setOnLongClickListener { menu(a); true }
    }

    // ───────────────────────── данные ─────────────────────────

    private fun reload() {
        Thread {
            AppRepo.load(this)
            val px = dp(Prefs.iconSize)
            val shape = Prefs.iconShape
            AppRepo.apps.forEach { it.icon(shape, px) }
            runOnUiThread { seed(); refresh() }
        }.start()
    }

    /** Первый запуск: док из приложений по умолчанию (телефон, SMS, браузер, камера) + иконка настроек на экране. */
    private fun seed() {
        if (Prefs.seeded || AppRepo.apps.isEmpty()) return
        Prefs.seeded = true
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        )
        val d = ArrayList<String>()
        for (i in probes) {
            val p = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            if (p != null && AppRepo.find(p) != null && p !in d) d.add(p)
        }
        Prefs.dock = d.joinToString(",")
        Prefs.home = packageName
    }

    private fun refresh() {
        rev = Prefs.rev
        buildHome()
        buildDock()
        applyFilter(search.text.toString())
    }

    private fun applyFilter(q: String) {
        val hid = Prefs.list(Prefs.hidden).toSet()
        shown = AppRepo.apps.filter { it.pkg !in hid && (q.isEmpty() || it.label.contains(q, true)) }
        gridAdapter.notifyDataSetChanged()
    }

    private fun launch(a: AppItem, v: View) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(a.pkg, a.cls)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val o = if (Prefs.animStyle == 3) null else ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height)
            startActivity(i, o?.toBundle())
        } catch (e: Exception) {
            toast("Не удалось открыть")
        }
        root.postDelayed({
            if (progress > 0f) {
                stopAnim()
                setProgress(0f)
                closed()
            }
        }, 450)
    }

    // ───────────────────────── меню ─────────────────────────

    private fun menu(a: AppItem) {
        val inHome = a.pkg in Prefs.list(Prefs.home)
        val inDock = a.pkg in Prefs.list(Prefs.dock)
        val names = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun add(n: String, f: () -> Unit) {
            names.add(n)
            acts.add(f)
        }
        if (inHome) {
            add("Убрать с главного экрана") { pin(a.pkg, false) }
        } else {
            add("На главный экран") { pin(a.pkg, true) }
        }
        if (inDock) {
            add("Убрать из дока") { dockSet(a.pkg, false) }
        } else {
            add("В док") { dockSet(a.pkg, true) }
        }
        add("Скрыть") { hide(a.pkg) }
        add("О приложении") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
        }
        add("Удалить") {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
        }
        AlertDialog.Builder(this).setTitle(a.label)
            .setItems(names.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    private fun quickMenu() {
        val items = arrayOf("Настройки лаунчера", "Обои", "Экран блокировки")
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                1 -> try {
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои"))
                } catch (e: Exception) {
                    toast("Приложение обоев не найдено")
                }
                else -> startActivity(Intent(this, SettingsActivity::class.java))
            }
        }.show()
    }

    private fun pin(pkg: String, on: Boolean) {
        val l = Prefs.list(Prefs.home)
        if (on) {
            if (l.size >= Prefs.cols * Prefs.rows) {
                toast("Главный экран заполнен")
                return
            }
            if (pkg !in l) l.add(pkg)
        } else {
            l.remove(pkg)
        }
        Prefs.home = l.joinToString(",")
        refresh()
    }

    private fun dockSet(pkg: String, on: Boolean) {
        val l = Prefs.list(Prefs.dock)
        if (on) {
            if (l.size >= 5) {
                toast("Док заполнен")
                return
            }
            if (pkg !in l) l.add(pkg)
        } else {
            l.remove(pkg)
        }
        Prefs.dock = l.joinToString(",")
        refresh()
    }

    private fun hide(pkg: String) {
        val l = Prefs.list(Prefs.hidden)
        if (pkg !in l) l.add(pkg)
        Prefs.hidden = l.joinToString(",")
        refresh()
        toast("Скрыто. Вернуть: Настройки → Скрытые приложения")
    }

    // ───────────────────────── шторка и анимации ─────────────────────────

    private fun span(): Float {
        val s = if (Prefs.animStyle == 1) root.height * 0.5f else root.height.toFloat()
        return if (s < 1f) 1f else s
    }

    private fun setProgress(p: Float) {
        progress = p.coerceIn(0f, 1f)
        val hh = root.height.toFloat()
        if (Prefs.animStyle == 1) {
            drawer.translationY = if (progress > 0f) 0f else hh + 1f
            drawer.alpha = progress
            val s = 0.92f + 0.08f * progress
            drawer.scaleX = s
            drawer.scaleY = s
        } else {
            drawer.translationY = (1f - progress) * hh
            drawer.alpha = 1f
            drawer.scaleX = 1f
            drawer.scaleY = 1f
        }
        val s = 1f - 0.05f * progress
        content.alpha = 1f - progress
        content.scaleX = s
        content.scaleY = s
    }

    private fun stopAnim() {
        val o = anim
        anim = null
        o?.cancel()
    }

    private fun release(vy: Float) {
        val open = if (abs(vy) > 900f) vy < 0 else progress > 0.45f
        animateTo(if (open) 1f else 0f)
    }

    private fun animateTo(t: Float) {
        stopAnim()
        if (t == 1f) prep()
        if (Prefs.animStyle == 3 || root.height == 0) {
            setProgress(t)
            if (t == 1f) iconsIn() else closed()
            return
        }
        val a = ValueAnimator.ofFloat(progress, t)
        a.duration = dur(if (t == 1f) 400L else 300L)
        a.interpolator = DecelerateInterpolator(1.8f)
        a.addUpdateListener { setProgress(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) {
                if (anim === a) {
                    anim = null
                    if (t == 0f) closed()
                }
            }
        })
        anim = a
        a.start()
        if (t == 1f) iconsIn()
    }

    private fun closed() {
        search.setText("")
        getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(search.windowToken, 0)
        grid.setSelection(0)
    }

    private fun cascade() = Prefs.animStyle == 0 || Prefs.animStyle == 2

    private fun prep() {
        if (!cascade()) return
        for (i in 0 until grid.childCount) {
            grid.getChildAt(i).apply {
                alpha = 0f
                scaleX = 0.7f
                scaleY = 0.7f
                translationY = dpf(40f)
            }
        }
    }

    /** Значки вылетают по очереди: пружина — волной по строкам, каскад — по диагонали. */
    private fun iconsIn() {
        if (!cascade()) return
        val st = Prefs.animStyle
        val cols = Prefs.cols
        for (i in 0 until grid.childCount) {
            val col = i % cols
            val row = i / cols
            val delay = if (st == 0) row * 30L + col * 12L else col * 40L + row * 15L
            grid.getChildAt(i).animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setStartDelay(dur(delay)).setDuration(dur(380))
                .setInterpolator(if (st == 0) OvershootInterpolator(1.6f) else DecelerateInterpolator(2f))
                .start()
        }
    }
}
