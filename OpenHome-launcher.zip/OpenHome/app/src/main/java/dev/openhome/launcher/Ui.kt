package dev.openhome.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
val BG = 0xFF0E0E13.toInt()
val CARD = 0xFF1A1A22.toInt()
val SUB = 0xFF9A9AAE.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun Context.reg(r: BroadcastReceiver, f: IntentFilter) {
    if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(r, f)
}

fun roundRect(color: Int, r: Float): GradientDrawable = GradientDrawable().apply {
    setColor(color)
    cornerRadius = r
}

/** Длительность анимации с учётом настройки скорости. */
fun dur(ms: Long): Long = ms * 100L / Prefs.animSpeed

/** Эффект нажатия: значок «вдавливается» и пружинит обратно. */
fun View.pressEffect() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.86f).scaleY(0.86f)
                .setDuration(dur(90)).setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f)
                .setDuration(dur(280)).setInterpolator(OvershootInterpolator(3f)).start()
        }
        false
    }
}

/** Ячейка приложения: значок + подпись. */
class Cell(ctx: Context) : LinearLayout(ctx) {
    private val img = ImageView(ctx)
    private val label = TextView(ctx)

    init {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, ctx.dp(6), 0, ctx.dp(6))
        addView(img, LinearLayout.LayoutParams(WRAP, WRAP))
        label.textSize = 11f
        label.maxLines = 1
        label.ellipsize = TextUtils.TruncateAt.END
        label.gravity = Gravity.CENTER
        addView(label, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(4) })
        pressEffect()
    }

    fun set(text: String, bmp: Bitmap, px: Int, showLabel: Boolean, color: Int) {
        img.setImageBitmap(bmp)
        img.layoutParams = LinearLayout.LayoutParams(px, px)
        label.text = text
        label.visibility = if (showLabel) View.VISIBLE else View.GONE
        label.setTextColor(color)
        label.setShadowLayer(if (color == Color.WHITE) 5f else 0f, 0f, 1f, Color.argb(170, 0, 0, 0))
    }
}

/** Контейнер с вертикальным драгом: тянем шторку приложений вверх/вниз, долгое нажатие по пустому месту. */
class DragLayout(ctx: Context) : FrameLayout(ctx) {
    var canStart: (Float) -> Boolean = { false }
    var onStart: () -> Unit = {}
    var onDrag: (Float) -> Unit = {}
    var onEnd: (Float) -> Unit = {}
    var onLong: (() -> Unit)? = null

    private var x0 = 0f
    private var y0 = 0f
    private var drag = false
    private var vt: VelocityTracker? = null
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val longRun = Runnable { onLong?.invoke() }

    private fun track(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                x0 = e.x
                y0 = e.y
                drag = false
                vt?.recycle()
                vt = VelocityTracker.obtain()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!drag) {
                    val dy = e.y - y0
                    val dx = e.x - x0
                    if (abs(dx) > slop || abs(dy) > slop) removeCallbacks(longRun)
                    if (abs(dy) > slop && abs(dy) > abs(dx) * 1.3f && canStart(dy)) {
                        drag = true
                        removeCallbacks(longRun)
                        onStart()
                    }
                }
                if (drag) onDrag(e.y - y0)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longRun)
                if (drag) {
                    vt?.computeCurrentVelocity(1000)
                    onEnd(vt?.yVelocity ?: 0f)
                }
                drag = false
                vt?.recycle()
                vt = null
            }
        }
        vt?.addMovement(e)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        track(e)
        return drag
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN && onLong != null) postDelayed(longRun, 520)
        track(e)
        return true
    }
}
