package dev.openhome.launcher

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.KeyguardManager
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import java.io.File

/** Фоны экрана блокировки: 0–4 градиенты, 5 — своё фото (lock_bg.jpg во внутренней памяти). */
object LockBg {
    val NAMES = listOf("Космос", "Закат", "Океан", "Лес", "Ночь", "Своё фото")
    private val G = arrayOf(
        intArrayOf(Color.parseColor("#0F0C29"), Color.parseColor("#302B63"), Color.parseColor("#24243E")),
        intArrayOf(Color.parseColor("#FF512F"), Color.parseColor("#DD2476")),
        intArrayOf(Color.parseColor("#0F2027"), Color.parseColor("#203A43"), Color.parseColor("#2C5364")),
        intArrayOf(Color.parseColor("#134E5E"), Color.parseColor("#71B280")),
        intArrayOf(Color.parseColor("#000000"), Color.parseColor("#1A1A2E"))
    )

    fun gradient(i: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, G[if (i in G.indices) i else 0])
}

class LockActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var box: LinearLayout
    private lateinit var notifBox: LinearLayout
    private var preview = false
    private var bob: ObjectAnimator? = null
    private var downY = 0f
    private var vt: VelocityTracker? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        preview = intent.getBooleanExtra("preview", false)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        build()
    }

    override fun onResume() {
        super.onResume()
        fillNotifs()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        reset()
    }

    override fun onDestroy() {
        bob?.cancel()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (preview) finish()
    }

    private fun build() {
        root = FrameLayout(this)
        val f = File(filesDir, "lock_bg.jpg")
        val photo = if (Prefs.lockBg == 5 && f.exists()) BitmapFactory.decodeFile(f.path) else null
        if (photo != null) {
            root.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(photo)
            }, MATCH, MATCH)
        } else {
            root.background = LockBg.gradient(Prefs.lockBg)
        }
        root.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(100, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(150, 0, 0, 0))
            )
        }, MATCH, MATCH)

        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(72), dp(24), dp(28))
        }
        box.addView(clock())
        box.addView(TextView(this).apply {
            text = battery()
            textSize = 13f
            gravity = if (Prefs.lockStyle == 1) Gravity.START else Gravity.CENTER_HORIZONTAL
            setTextColor(Color.argb(190, 255, 255, 255))
            setPadding(0, dp(6), 0, dp(14))
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        notifBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(notifBox, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val bottom = FrameLayout(this)
        val torch = circle("🔦")
        torch.setOnClickListener { toggleTorch(torch) }
        val cam = circle("📷")
        cam.setOnClickListener { openCamera() }
        val hint = TextView(this).apply {
            text = "⌃\nПроведите вверх"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.argb(200, 255, 255, 255))
        }
        bob = ObjectAnimator.ofFloat(hint, "translationY", 0f, -dpf(8f), 0f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        bottom.addView(torch, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.START or Gravity.BOTTOM))
        bottom.addView(cam, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.END or Gravity.BOTTOM))
        bottom.addView(hint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM))
        box.addView(bottom, LinearLayout.LayoutParams(MATCH, dp(70)))
        root.addView(box, MATCH, MATCH)
        setContentView(root)

        // свайп вверх — разблокировать
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.y
                    vt?.recycle()
                    vt = VelocityTracker.obtain()
                    vt?.addMovement(e)
                }
                MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(e)
                    val dy = if (e.y - downY < 0f) e.y - downY else 0f
                    val p = (-dy / root.height).coerceIn(0f, 1f)
                    box.translationY = dy
                    box.alpha = 1f - p * 1.4f
                    box.scaleX = 1f - 0.08f * p
                    box.scaleY = 1f - 0.08f * p
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    vt?.addMovement(e)
                    vt?.computeCurrentVelocity(1000)
                    val vy = vt?.yVelocity ?: 0f
                    vt?.recycle()
                    vt = null
                    if (downY - e.y > root.height * 0.22f || vy < -1200f) unlock() else reset()
                }
            }
            true
        }
    }

    private fun circle(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 22f
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(60, 255, 255, 255))
        }
        pressEffect()
    }

    private fun clock(): View {
        val hh = if (Prefs.h24) "HH" else "hh"
        fun tc(f: String, sz: Float, c: Int, tf: Typeface): TextClock = TextClock(this).apply {
            format12Hour = f
            format24Hour = f
            textSize = sz
            setTextColor(c)
            typeface = tf
            includeFontPadding = false
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val dateFmt = "EEEE, d MMMM"
        when (Prefs.lockStyle) {
            1 -> {
                col.gravity = Gravity.START
                col.addView(tc(hh, 110f, Color.WHITE, Typeface.DEFAULT_BOLD))
                col.addView(tc("mm", 110f, Prefs.accent, Typeface.DEFAULT_BOLD))
                col.addView(tc(dateFmt, 16f, Color.WHITE, Typeface.DEFAULT))
            }
            2 -> {
                col.gravity = Gravity.CENTER_HORIZONTAL
                col.addView(tc(dateFmt, 16f, Prefs.accent, Typeface.DEFAULT_BOLD))
                col.addView(tc("$hh:mm", 76f, Color.WHITE, Typeface.DEFAULT_BOLD))
            }
            else -> {
                col.gravity = Gravity.CENTER_HORIZONTAL
                col.addView(tc("$hh:mm", 92f, Color.WHITE, Typeface.create("sans-serif-thin", Typeface.NORMAL)))
                col.addView(tc(dateFmt, 17f, Color.WHITE, Typeface.DEFAULT))
            }
        }
        return col
    }

    private fun battery(): String {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return ""
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / (if (scale > 0) scale else 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        return (if (charging) "⚡ " else "🔋 ") + lvl + "%"
    }

    private fun fillNotifs() {
        notifBox.removeAllViews()
        if (!Prefs.lockNotif) return
        NotifService.items.take(4).forEachIndexed { idx, n ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundRect(Color.argb(46, 255, 255, 255), dpf(18f))
                setPadding(dp(16), dp(12), dp(16), dp(12))
                alpha = 0f
                translationY = dpf(24f)
            }
            card.addView(TextView(this).apply {
                text = if (n.title.isEmpty()) n.app else n.app + " · " + n.title
                setTextColor(Color.WHITE)
                textSize = 13.5f
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            if (n.text.isNotEmpty()) {
                card.addView(TextView(this).apply {
                    text = n.text
                    setTextColor(Color.argb(210, 255, 255, 255))
                    textSize = 13f
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                })
            }
            notifBox.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
            card.animate().alpha(1f).translationY(0f).setStartDelay(idx * 70L).setDuration(380)
                .setInterpolator(DecelerateInterpolator(2f)).start()
        }
    }

    private fun reset() {
        box.animate().translationY(0f).alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(320).setInterpolator(OvershootInterpolator(1.2f)).start()
    }

    private fun unlock() {
        box.animate().translationY(-root.height.toFloat()).alpha(0f).setDuration(180)
            .withEndAction { dismiss() }.start()
    }

    private fun dismiss() {
        if (preview) {
            finish()
            return
        }
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isKeyguardLocked) {
            finish()
            return
        }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
            override fun onDismissCancelled() { reset() }
            override fun onDismissError() { finish() }
        })
    }

    private fun toggleTorch(btn: TextView) {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            btn.alpha = if (torchOn) 1f else 0.6f
        } catch (e: Exception) {
            toast("Фонарик недоступен")
        }
    }

    private fun openCamera() {
        try {
            startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) {
                toast("Камера не найдена")
            }
        }
    }

    companion object {
        var torchOn = false
    }
}
