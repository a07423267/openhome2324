package dev.openhome.launcher

import android.content.Context
import android.content.SharedPreferences
import kotlin.reflect.KProperty

class IntP(private val k: String, private val d: Int) {
    operator fun getValue(t: Any?, p: KProperty<*>): Int = Prefs.sp.getInt(k, d)
    operator fun setValue(t: Any?, p: KProperty<*>, v: Int) {
        Prefs.sp.edit().putInt(k, v).apply()
        Prefs.rev++
    }
}

class BoolP(private val k: String, private val d: Boolean) {
    operator fun getValue(t: Any?, p: KProperty<*>): Boolean = Prefs.sp.getBoolean(k, d)
    operator fun setValue(t: Any?, p: KProperty<*>, v: Boolean) {
        Prefs.sp.edit().putBoolean(k, v).apply()
        Prefs.rev++
    }
}

class StrP(private val k: String, private val d: String) {
    operator fun getValue(t: Any?, p: KProperty<*>): String = Prefs.sp.getString(k, d) ?: d
    operator fun setValue(t: Any?, p: KProperty<*>, v: String) {
        Prefs.sp.edit().putString(k, v).apply()
        Prefs.rev++
    }
}

/** Все настройки лаунчера. rev растёт при любом изменении — лаунчер по нему перерисовывается. */
object Prefs {
    internal lateinit var sp: SharedPreferences
    @Volatile var rev = 0

    // сетка и значки
    var cols by IntP("cols", 4)
    var rows by IntP("rows", 4)
    var iconSize by IntP("iconSize", 56)
    var iconShape by IntP("iconShape", 2)
    var labels by BoolP("labels", true)

    // внешний вид
    var accent by IntP("accent", 0xFF7C5CFF.toInt())
    var dim by IntP("dim", 15)
    var dockAlpha by IntP("dockAlpha", 45)
    var drawerAlpha by IntP("drawerAlpha", 88)
    var darkText by BoolP("darkText", false)
    var clockStyle by IntP("clockStyle", 0)
    var h24 by BoolP("h24", true)

    // анимации: 0 пружина, 1 масштаб, 2 каскад, 3 без анимации
    var animStyle by IntP("animStyle", 0)
    var animSpeed by IntP("animSpeed", 100)

    // экран блокировки
    var lockOn by BoolP("lockOn", false)
    var lockStyle by IntP("lockStyle", 0)
    var lockBg by IntP("lockBg", 0)
    var lockNotif by BoolP("lockNotif", true)

    // данные
    var home by StrP("home", "")
    var dock by StrP("dock", "")
    var hidden by StrP("hidden", "")
    var seeded by BoolP("seeded", false)

    fun list(s: String): MutableList<String> =
        if (s.isEmpty()) mutableListOf() else s.split(",").toMutableList()

    fun init(c: Context) {
        sp = c.applicationContext.getSharedPreferences("openhome", Context.MODE_PRIVATE)
    }

    fun reset() {
        sp.edit().clear().apply()
        rev++
    }
}
