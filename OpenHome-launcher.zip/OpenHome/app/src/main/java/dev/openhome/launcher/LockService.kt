package dev.openhome.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Следит за выключением экрана и поверх системной блокировки показывает наш экран (LockActivity). */
class LockService : Service() {
    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF && Prefs.lockOn) {
                val l = Intent(c, LockActivity::class.java).addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                )
                try {
                    c.startActivity(l)
                } catch (e: Exception) {
                }
            }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("lock", "Экран блокировки", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "lock")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("OpenHome: экран блокировки активен")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        reg(rcv, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onDestroy() {
        try {
            unregisterReceiver(rcv)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    companion object {
        fun ensure(c: Context) {
            if (!Prefs.lockOn) return
            try {
                c.startForegroundService(Intent(c, LockService::class.java))
            } catch (e: Exception) {
            }
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, LockService::class.java))
        }
    }
}
