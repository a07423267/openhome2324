package dev.openhome.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.io.File

/** Настройки в стиле ColorOS: форма и размер значков, сетка, анимации, часы, экран блокировки. */
class SettingsActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var preview: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val sv = ScrollView(this).apply {
            setBackgroundColor(BG)
            isVerticalScrollBarEnabled = false
        }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(40))
        }
        sv.addView(box)
        setContentView(sv)
        build()
        if (AppRepo.apps.isEmpty()) {
            Thread {
                AppRepo.load(this)
                runOnUiThread { fill() }
            }.start()
        }
    }

    // ───────────── строительные блоки ─────────────

    private fun tv(t: String, sz: Float, c: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = t
        textSize = sz
        setTextColor(c)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun section(t: String) {
        box.addView(tv(t.uppercase(), 12f, Prefs.accent, true).apply {
            letterSpacing = 0.1f
            setPadding(0, dp(26), 0, dp(8))
        })
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(CARD, dpf(16f))
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        box.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        return c
    }

    private fun go(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Недоступно на этом устройстве")
        }
    }

    private fun choice(t: String, items: List<String>, rd: () -> Int, wr: (Int) -> Unit) {
        val c = card()
        c.addView(tv(t, 15f, Color.WHITE))
        val v = tv(items[rd().coerceIn(0, items.size - 1)], 13f, SUB)
        c.addView(v)
        c.setOnClickListener {
            AlertDialog.Builder(this).setTitle(t)
                .setSingleChoiceItems(items.toTypedArray(), rd()) { d, i ->
                    wr(i)
                    v.text = items[i]
                    fill()
                    d.dismiss()
                }.show()
        }
    }

    private fun sw(t: String, rd: () -> Boolean, wr: (Boolean) -> Unit) {
        val c = card()
        c.addView(Switch(this).apply {
            text = t
            textSize = 15f
            setTextColor(Color.WHITE)
            isChecked = rd()
            setOnCheckedChangeListener { _, on -> wr(on) }
        })
    }

    private fun seek(t: String, mn: Int, mx: Int, unit: String, rd: () -> Int, wr: (Int) -> Unit) {
        val c = card()
        val label = tv("$t: ${rd()}$unit", 15f, Color.WHITE)
        c.addView(label)
        c.addView(SeekBar(this).apply {
            max = mx - mn
            progress = rd() - mn
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    wr(p + mn)
                    label.text = "$t: ${p + mn}$unit"
                    fill()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun btn(t: String, sub: String = "", on: () -> Unit) {
        val c = card()
        c.addView(tv(t, 15f, Color.WHITE))
        if (sub.isNotEmpty()) c.addView(tv(sub, 12.5f, SUB))
        c.setOnClickListener { on() }
    }

    private fun colors() {
        val c = card()
        c.addView(tv("Акцентный цвет", 15f, Color.WHITE))
        val row = LinearLayout(this).apply { setPadding(0, dp(10), 0, 0) }
        val list = intArrayOf(
            0xFF7C5CFF.toInt(), 0xFF00B8D4.toInt(), 0xFF00C853.toInt(), 0xFFFFB300.toInt(),
            0xFFFF5252.toInt(), 0xFFFF4081.toInt(), 0xFFFFFFFF.toInt()
        )
        for (k in list) {
            val dot = View(this)
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(k)
                if (k == Prefs.accent) setStroke(dp(3), Color.GRAY)
            }
            dot.setOnClickListener {
                Prefs.accent = k
                build()
            }
            row.addView(dot, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) })
        }
        c.addView(row)
    }

    private fun fill() {
        if (!::preview.isInitialized) return
        preview.removeAllViews()
        val px = dp(Prefs.iconSize)
        for (a in AppRepo.apps.take(5)) {
            val iv = ImageView(this)
            iv.setImageBitmap(a.icon(Prefs.iconShape, px))
            preview.addView(iv, LinearLayout.LayoutParams(px, px).apply { rightMargin = dp(10) })
        }
    }

    // ───────────── экран ─────────────

    private fun build() {
        box.removeAllViews()
        box.addView(tv("OpenHome", 30f, Color.WHITE, true))
        box.addView(tv("Открытый лаунчер: анимации, кастомизация, свой экран блокировки", 13f, SUB).apply {
            setPadding(0, dp(4), 0, 0)
        })

        section("Значки")
        val pc = card()
        preview = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        pc.addView(preview)
        fill()
        choice("Форма значков", IconShaper.NAMES, { Prefs.iconShape }, { Prefs.iconShape = it })
        seek("Размер значков", 40, 76, " dp", { Prefs.iconSize }, { Prefs.iconSize = it })
        seek("Колонок", 3, 6, "", { Prefs.cols }, { Prefs.cols = it })
        seek("Строк на главном экране", 3, 6, "", { Prefs.rows }, { Prefs.rows = it })
        sw("Подписи под значками", { Prefs.labels }, { Prefs.labels = it })

        section("Внешний вид")
        colors()
        seek("Затемнение обоев", 0, 70, "%", { Prefs.dim }, { Prefs.dim = it })
        seek("Прозрачность дока", 0, 100, "%", { Prefs.dockAlpha }, { Prefs.dockAlpha = it })
        seek("Плотность фона меню приложений", 20, 100, "%", { Prefs.drawerAlpha }, { Prefs.drawerAlpha = it })
        sw("Тёмный текст (для светлых обоев)", { Prefs.darkText }, { Prefs.darkText = it })
        choice("Стиль часов", listOf("Тонкие", "Жирные", "Лёгкие"), { Prefs.clockStyle }, { Prefs.clockStyle = it })
        sw("24-часовой формат", { Prefs.h24 }, { Prefs.h24 = it })

        section("Анимации")
        choice("Стиль анимации", listOf("Пружина", "Масштаб", "Каскад", "Без анимации"), { Prefs.animStyle }, { Prefs.animStyle = it })
        seek("Скорость анимаций", 50, 200, "%", { Prefs.animSpeed }, { Prefs.animSpeed = it })

        section("Экран блокировки")
        sw("Включить свой экран блокировки", { Prefs.lockOn }) { on ->
            Prefs.lockOn = on
            if (on) {
                lockPerms()
                LockService.ensure(this)
            } else {
                LockService.stop(this)
            }
        }
        choice("Стиль часов", listOf("Тонкие по центру", "Столбиком", "Жирные + дата"), { Prefs.lockStyle }, { Prefs.lockStyle = it })
        choice("Фон", LockBg.NAMES, { Prefs.lockBg }, { Prefs.lockBg = it })
        btn("Выбрать своё фото для фона") {
            try {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 7
                )
            } catch (e: Exception) {
                toast("Галерея недоступна")
            }
        }
        sw("Уведомления на экране блокировки", { Prefs.lockNotif }, { Prefs.lockNotif = it })
        btn("Доступ к уведомлениям", "Нужен, чтобы показывать их на экране блокировки") {
            go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("Разрешение «Поверх других окон»", "Без него экран блокировки не сможет появиться") { overlay() }
        btn("Автозапуск и батарея", "Vivo/Oppo/Xiaomi: разреши автозапуск и работу в фоне без ограничений") {
            go(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        btn("Предпросмотр экрана блокировки") {
            go(Intent(this, LockActivity::class.java).putExtra("preview", true))
        }

        section("Система")
        btn("Сделать лаунчером по умолчанию") {
            try {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (e: Exception) {
                go(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        btn("Скрытые приложения") { hiddenDialog() }
        btn("Сбросить все настройки") {
            Prefs.reset()
            toast("Сброшено")
            build()
        }
        box.addView(tv("OpenHome • открытый исходный код • MIT", 12f, SUB).apply { setPadding(0, dp(24), 0, 0) })
    }

    private fun lockPerms() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        overlay()
    }

    private fun overlay() {
        if (Settings.canDrawOverlays(this)) {
            toast("Разрешение уже выдано")
            return
        }
        go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun hiddenDialog() {
        val apps = AppRepo.apps
        val hid = Prefs.list(Prefs.hidden)
        val checked = BooleanArray(apps.size) { apps[it].pkg in hid }
        AlertDialog.Builder(this).setTitle("Скрытые приложения")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("OK") { _, _ ->
                Prefs.hidden = apps.filterIndexed { i, _ -> checked[i] }.joinToString(",") { it.pkg }
            }
            .show()
    }

    // ───────────── своё фото для экрана блокировки ─────────────

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        val u = d?.data
        if (rq == 7 && rs == RESULT_OK && u != null) saveBg(u)
    }

    private fun saveBg(u: Uri) {
        Thread {
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
                var ss = 1
                while (o.outWidth / ss > 1600 || o.outHeight / ss > 2800) ss *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = ss }
                val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
                if (bmp == null) {
                    runOnUiThread { toast("Не удалось загрузить фото") }
                    return@Thread
                }
                File(filesDir, "lock_bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                Prefs.lockBg = 5
                runOnUiThread {
                    toast("Фон сохранён")
                    build()
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Не удалось загрузить фото") }
            }
        }.start()
    }
}
